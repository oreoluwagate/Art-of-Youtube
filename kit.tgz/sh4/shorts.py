# Week-4 test pack: "MAX VS. THE MACHINE" series, 7 shorts (171-177). Cast = Kevin, Max, Ben + 'machine' (gadget voice, phone filter).
SH = []
def S(**k): SH.append(k)
G = lambda id, refs, p: dict(id=id, refs=refs, prompt=p)
KMB = lambda a='smug', b='deadpan', c='excited': [('kevin', a), ('max', b), ('ben', c)]
M = lambda t: ('L', 'machine', t, {'shot': ('gag',), 'phone': True})
def FOLLOW(nxt):
    return [('S', 'sting2', 0.0),
            ('L', 'max', "[deadpan, to camera] Follow. Kevin bought more machines.",
             {'shot': ('card', 'title', 'FOLLOW', ['Max vs. The Machine', nxt]), 'hold': 0.7})]

S(n=171, title='MAX VS. THE MACHINE #1: THE $400 TIRE GAUGE', set='repair', cast=KMB('talking', 'deadpan', 'nervous'),
  gag=G('g171', ['kevin', 'set_repair'], "Kevin (from the character reference) proudly holding up a sleek, glowing, oversized smart tire pressure gauge covered in blue lights, connected by a cable to his phone; the phone screen shows a spinning loading circle and the word 'PAIRING...'. He stands next to a car tire in the repair bay."),
  beats=[
    ('L', 'kevin', "[proud] Max, meet the four-hundred-dollar smart tire gauge.", {'pose': 'talking'}),
    ('S', 'click2', 0.0), ('H', 1.6, ('gag',)),
    M("[robotic monotone] Pairing. Please wait."),
    ('L', 'ben', "It's been pairing since Tuesday.", {'pose': 'nervous'}),
    ('L', 'max', "[deadpan] Thirty-two P S I.", {'pose': 'deadpan'}),
    ('L', 'kevin', "You can't possibly know that.", {'pose': 'panicked'}),
    ('L', 'max', "[dry] Three-dollar gauge. Didn't need Wi-Fi.", {'pose': 'sideeye', 'hold': 0.3}),
    M("[robotic monotone] Pairing failed. Please subscribe."),
    ('H', 0.9, ('stare', 'kevin')),
  ] + FOLLOW('#2 is next'))

S(n=172, title='MAX VS. THE MACHINE #2: THE AI THAT LISTENS', set='lot', cast=KMB('talking', 'deadpan', 'excited'),
  gag=G('g172', ['kevin', 'set_lot'], "Kevin (from the character reference) in the parking lot holding a giant fuzzy boom microphone over the open hood of a car, a laptop on the hood showing colorful sound waves and the word 'ANALYZING...', Kevin squinting seriously like a scientist."),
  beats=[
    ('L', 'kevin', "[excited] This AI can hear what's wrong with any engine.", {'pose': 'talking'}),
    ('S', 'click2', 0.0), ('H', 1.6, ('gag',)),
    M("[robotic monotone] Sound detected. Engine."),
    ('L', 'ben', "[whispering] I mean... it's not wrong.", {'pose': 'whisper'}),
    M("[robotic monotone] Sound detected. Louder engine."),
    ('L', 'max', "[deadpan] Serpentine belt. It's glazed.", {'pose': 'deadpan'}),
    ('L', 'kevin', "You heard that from across the lot?", {'pose': 'panicked'}),
    ('L', 'max', "[dry] Ears. No charger.", {'pose': 'sideeye', 'hold': 0.6}),
  ] + FOLLOW('#3 is next'))

S(n=173, title='MAX VS. THE MACHINE #3: THE $6,000 HEAT CAMERA', set='repair', cast=KMB('smug', 'deadpan', 'nervous'),
  gag=G('g173', ['kevin', 'set_repair'], "Kevin (from the character reference) aiming a big expensive thermal imaging camera; its screen shows a rainbow heat image where the only glowing bright spot is a steaming coffee mug on the workbench, not the car. Kevin looks proud anyway."),
  beats=[
    ('L', 'kevin', "[proud] Six-thousand-dollar thermal camera. It sees heat.", {'pose': 'smug'}),
    ('S', 'click2', 0.0), ('H', 1.6, ('gag',)),
    M("[robotic monotone] Hot spot detected."),
    ('L', 'ben', "That's Max's coffee.", {'pose': 'nervous'}),
    ('L', 'kevin', "Then where's the coolant leak?", {'pose': 'talking'}),
    ('L', 'max', "[deadpan, sniffs] Smells sweet. Lower radiator hose.", {'pose': 'deadpan'}),
    ('L', 'kevin', "You can't smell a diagnosis.", {'pose': 'panicked'}),
    ('L', 'max', "[dry] I just did.", {'pose': 'halfsmile', 'hold': 0.6}),
  ] + FOLLOW('#4 is next'))

S(n=174, title='MAX VS. THE MACHINE #4: THE VR HEADSET', set='repair', cast=KMB('talking', 'deadpan', 'panicked'),
  gag=G('g174', ['kevin', 'set_repair'], "Kevin (from the character reference) wearing a bulky glowing virtual reality headset, arms stretched out in front of him, confidently walking straight toward the steel post of a car lift in the repair bay, about to bonk into it."),
  beats=[
    ('L', 'kevin', "[amazed] With this headset, I can see inside the engine.", {'pose': 'talking'}),
    ('S', 'whoosh', 0.0), ('H', 1.5, ('gag',)),
    ('L', 'ben', "Kevin, the lift!", {'pose': 'panicked'}),
    ('S', 'clang', 0.0), ('H', 0.8, ('stare', 'ben')),
    ('L', 'kevin', "[dazed] I saw the engine.", {'pose': 'defeated'}),
    M("[robotic monotone] Battery low. Please charge headset."),
    ('L', 'max', "[deadpan] Flashlight says oil pan gasket.", {'pose': 'deadpan'}),
    ('L', 'kevin', "Does your flashlight need charging?", {'pose': 'defeated'}),
    ('L', 'max', "[dry] Two double-A's. Since nineteen eighty-seven.", {'pose': 'sideeye', 'hold': 0.6}),
  ] + FOLLOW('#5 is next'))

S(n=175, title='MAX VS. THE MACHINE #5: THE ROBOT MECHANIC', set='repair', cast=KMB('smug', 'deadpan', 'panicked'),
  gag=G('g175', ['kevin', 'set_repair'], "A huge yellow industrial robot arm in the repair bay spinning a car wheel at crazy speed like a pizza, lug nuts flying off in every direction with motion lines, while Kevin (from the character reference) proudly gestures at it like a game-show host."),
  beats=[
    ('L', 'kevin', "[proud] Meet our new robot mechanic. It never takes breaks.", {'pose': 'smug'}),
    M("[robotic monotone] Tightening lug nuts. Maximum power."),
    ('S', 'ratchet', 0.0), ('S', 'clang', 0.5), ('H', 1.2, ('gag',)),
    ('L', 'ben', "The wheel's coming off!", {'pose': 'panicked'}),
    M("[robotic monotone, cheerful] Task complete."),
    ('L', 'max', "[deadpan] Eighty foot-pounds. Star pattern. By hand.", {'pose': 'deadpan'}),
    ('L', 'kevin', "Can the robot learn that?", {'pose': 'defeated'}),
    ('L', 'max', "[dry] Took me forty years. Good luck.", {'pose': 'sideeye', 'hold': 0.6}),
  ] + FOLLOW('#6 is next'))

S(n=176, title='MAX VS. THE MACHINE #6: THE AI RECEPTIONIST', set='desk', cast=KMB('smug', 'deadpan', 'excited'),
  gag=G('g176', ['kevin', 'set_desk'], "On the shop's front counter, a smug glowing smart-speaker robot with a little cartoon face, next to a screen that reads 'BOOKED: 1 BICYCLE TUNE-UP - MARCH'. Kevin (from the character reference) beams at it proudly."),
  beats=[
    ('L', 'kevin', "[smug] No more phones for Max. The AI answers now.", {'pose': 'smug'}),
    ('S', 'ring', 0.0), ('H', 0.6, ('gag',)),
    M("[robotic, overly cheerful] Thank you for calling Maximum Automotive!"),
    ('L', 'ben', "[on the phone] Hi, my brakes are squealing.", {'shot': ('gag',), 'phone': True}),
    M("[robotic, overly cheerful] Great! I booked you a bicycle tune-up. For March."),
    ('L', 'kevin', "[nervous] It's still learning.", {'pose': 'defeated'}),
    ('L', 'max', "[deadpan, into the phone] Bring it in. I'll look now.", {'pose': 'talking'}),
    ('L', 'ben', "Wait, that's it?", {'pose': 'excited'}),
    ('L', 'max', "[dry] It's fine. Kevin's still learning too.", {'pose': 'sideeye', 'hold': 0.6}),
  ] + FOLLOW('#7 is next'))

S(n=177, title='MAX VS. THE MACHINE #7: THE SCANNER STRIKES BACK', set='lot', cast=KMB('smug', 'deadpan', 'nervous'),
  gag=G('g177', ['kevin', 'set_lot'], "Kevin (from the character reference) in the parking lot holding a huge, overly complicated diagnostic tablet with antennas and blinking lights; its screen shows 'INSTALLING UPDATE 1 OF 47' and a progress bar stuck at 3 percent. A car next to him has a puddle of green coolant under it."),
  beats=[
    ('L', 'kevin', "[proud] The twelve-thousand-dollar scanner got an update.", {'pose': 'smug'}),
    ('S', 'click2', 0.0), ('H', 1.4, ('gag',)),
    M("[robotic monotone] Installing update. Four hours remaining."),
    ('L', 'ben', "The car's still leaking.", {'pose': 'nervous'}),
    ('L', 'max', "[deadpan] Water pump. Same as last time.", {'pose': 'deadpan'}),
    ('L', 'kevin', "This time we'll be sure.", {'pose': 'talking'}),
    ('S', 'bell', 0.0),
    M("[robotic monotone] Update complete. Possible. Water pump."),
    ('H', 0.9, ('stare', 'max')),
    ('L', 'max', "[dry] Twelve thousand dollars. And it copied me.", {'pose': 'sideeye', 'hold': 0.6}),
  ] + FOLLOW('more machines coming'))
